// import React from 'react'

// export default function Diseases() {
//   return (
//     <>
//      <div className="dis">
//      <h2 className="h2-dis">Diseases : </h2>
//         <textarea className="diseases-textarea" placeholder=""></textarea>

//      </div>
     
//      </>
   
//   )
// }
